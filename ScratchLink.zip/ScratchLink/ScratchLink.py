import urllib.request
import os

slpage = urllib.request.urlopen("https://api.scratch.mit.edu")
class give:
    class count:
        def countallprojects():
        sln = 8
        slval = ""
        slpage = urllib.request.urlopen(f"https://api.scratch.mit.edu/users/{user}/messages/count")
        while not slpage[sln] == "}":
            sln += 1
            slval = slval + page[n]
            return slval
    class user:
        def giveid(user):
            sln = 7
            slval = ""
            slpage = urllib.request.urlopen(f"https://api.scratch.mit.edu/users/{user}")
            if not slpage == ("{\"code\":\"NotFound\",\"message\":\"\"}"):
                #Add check for no basic HTML returns.
                while not slpage[sln] == ",":
                    sln += 1
                    slval = slval + page[n]
                return slval
        def unreadmsgs(user):
            if not slpage == "{\"code\":\"Unauthorized\",\"message\":\"\"}":
                print("This function isn't finished. Try again next version.")
            else:
                os.system("cls")
                print("[ScratchLink] ERR: Sorry, but you don't have the permissions to access this data.")
        class count:
            def unreadmsgs(user):
                sln = 10
                slval = ""
                slpage = urllib.request.urlopen(f"https://api.scratch.mit.edu/users/{user}/messages/count")
                while not slpage[sln] == "}":
                    sln += 1
                    slval = slval + page[n]
                return slval
                        
